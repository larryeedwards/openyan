﻿using System;

// Token: 0x02000437 RID: 1079
public static class InputNames
{
	// Token: 0x04002302 RID: 8962
	public const int Mouse_LMB = 0;

	// Token: 0x04002303 RID: 8963
	public const int Mouse_RMB = 1;

	// Token: 0x04002304 RID: 8964
	public const int Mouse_MMB = 2;

	// Token: 0x04002305 RID: 8965
	public const string Xbox_A = "A";

	// Token: 0x04002306 RID: 8966
	public const string Xbox_B = "B";

	// Token: 0x04002307 RID: 8967
	public const string Xbox_X = "X";

	// Token: 0x04002308 RID: 8968
	public const string Xbox_Y = "Y";

	// Token: 0x04002309 RID: 8969
	public const string Xbox_LB = "LB";

	// Token: 0x0400230A RID: 8970
	public const string Xbox_RB = "RB";

	// Token: 0x0400230B RID: 8971
	public const string Xbox_LT = "LT";

	// Token: 0x0400230C RID: 8972
	public const string Xbox_RT = "RT";

	// Token: 0x0400230D RID: 8973
	public const string Xbox_LS = "LS";

	// Token: 0x0400230E RID: 8974
	public const string Xbox_RS = "RS";

	// Token: 0x0400230F RID: 8975
	public const string Xbox_Start = "Start";

	// Token: 0x04002310 RID: 8976
	public const string Xbox_Back = "Back";

	// Token: 0x04002311 RID: 8977
	public const string Yanvania_Horizontal = "VaniaHorizontal";

	// Token: 0x04002312 RID: 8978
	public const string Yanvania_Vertical = "VaniaVertical";

	// Token: 0x04002313 RID: 8979
	public const string Yanvania_Attack = "VaniaAttack";

	// Token: 0x04002314 RID: 8980
	public const string Yanvania_Jump = "VaniaJump";
}
