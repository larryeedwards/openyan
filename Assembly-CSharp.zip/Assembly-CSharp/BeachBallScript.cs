﻿using System;
using UnityEngine;

// Token: 0x02000334 RID: 820
public class BeachBallScript : MonoBehaviour
{
}
