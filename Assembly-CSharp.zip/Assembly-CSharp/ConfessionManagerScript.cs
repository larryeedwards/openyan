﻿using System;
using UnityEngine;

// Token: 0x02000372 RID: 882
public class ConfessionManagerScript : MonoBehaviour
{
}
