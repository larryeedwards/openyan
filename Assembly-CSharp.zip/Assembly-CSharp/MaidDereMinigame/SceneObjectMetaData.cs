﻿using System;
using MaidDereMinigame.Malee;

namespace MaidDereMinigame
{
	// Token: 0x02000162 RID: 354
	[Serializable]
	public class SceneObjectMetaData : ReorderableArray<SceneObject>
	{
	}
}
