﻿using System;
using UnityEngine;

// Token: 0x0200043C RID: 1084
public class InventoryItemScript : MonoBehaviour
{
	// Token: 0x04002390 RID: 9104
	public int Height;

	// Token: 0x04002391 RID: 9105
	public int Width;

	// Token: 0x04002392 RID: 9106
	public float InventorySize;

	// Token: 0x04002393 RID: 9107
	public Vector3 InventoryPosition;
}
