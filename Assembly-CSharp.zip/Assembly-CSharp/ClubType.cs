﻿using System;

// Token: 0x020003B4 RID: 948
public enum ClubType
{
	// Token: 0x04001DB9 RID: 7609
	None,
	// Token: 0x04001DBA RID: 7610
	Cooking,
	// Token: 0x04001DBB RID: 7611
	Drama,
	// Token: 0x04001DBC RID: 7612
	Occult,
	// Token: 0x04001DBD RID: 7613
	Art,
	// Token: 0x04001DBE RID: 7614
	LightMusic,
	// Token: 0x04001DBF RID: 7615
	MartialArts,
	// Token: 0x04001DC0 RID: 7616
	Photography,
	// Token: 0x04001DC1 RID: 7617
	Science,
	// Token: 0x04001DC2 RID: 7618
	Sports,
	// Token: 0x04001DC3 RID: 7619
	Gardening,
	// Token: 0x04001DC4 RID: 7620
	Gaming,
	// Token: 0x04001DC5 RID: 7621
	Council,
	// Token: 0x04001DC6 RID: 7622
	Bully,
	// Token: 0x04001DC7 RID: 7623
	Delinquent,
	// Token: 0x04001DC8 RID: 7624
	Nemesis = 99,
	// Token: 0x04001DC9 RID: 7625
	Teacher,
	// Token: 0x04001DCA RID: 7626
	GymTeacher,
	// Token: 0x04001DCB RID: 7627
	Nurse,
	// Token: 0x04001DCC RID: 7628
	Counselor,
	// Token: 0x04001DCD RID: 7629
	Headmaster
}
