﻿using System;

// Token: 0x02000344 RID: 836
public enum BucketContentsType
{
	// Token: 0x04001733 RID: 5939
	Water,
	// Token: 0x04001734 RID: 5940
	Gas,
	// Token: 0x04001735 RID: 5941
	Weights
}
