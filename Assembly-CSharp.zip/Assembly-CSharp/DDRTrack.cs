﻿using System;
using System.Collections.Generic;

// Token: 0x0200012E RID: 302
[Serializable]
public class DDRTrack
{
	// Token: 0x04000780 RID: 1920
	public List<float> Nodes;
}
