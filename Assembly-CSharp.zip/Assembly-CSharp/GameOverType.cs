﻿using System;

// Token: 0x02000535 RID: 1333
public enum GameOverType
{
	// Token: 0x04002FC5 RID: 12229
	None,
	// Token: 0x04002FC6 RID: 12230
	Blood,
	// Token: 0x04002FC7 RID: 12231
	Insanity,
	// Token: 0x04002FC8 RID: 12232
	Lewd,
	// Token: 0x04002FC9 RID: 12233
	Murder,
	// Token: 0x04002FCA RID: 12234
	Stalking,
	// Token: 0x04002FCB RID: 12235
	Violence,
	// Token: 0x04002FCC RID: 12236
	Weapon
}
