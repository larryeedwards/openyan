﻿using System;

namespace AmplifyMotion
{
	// Token: 0x02000289 RID: 649
	public enum Quality
	{
		// Token: 0x0400117E RID: 4478
		Mobile,
		// Token: 0x0400117F RID: 4479
		Standard,
		// Token: 0x04001180 RID: 4480
		Standard_SM3,
		// Token: 0x04001181 RID: 4481
		SoftEdge_SM3
	}
}
