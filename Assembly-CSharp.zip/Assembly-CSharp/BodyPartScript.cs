﻿using System;
using UnityEngine;

// Token: 0x0200033F RID: 831
public class BodyPartScript : MonoBehaviour
{
	// Token: 0x040016F1 RID: 5873
	public bool Sacrifice;

	// Token: 0x040016F2 RID: 5874
	public int StudentID;

	// Token: 0x040016F3 RID: 5875
	public int Type;
}
