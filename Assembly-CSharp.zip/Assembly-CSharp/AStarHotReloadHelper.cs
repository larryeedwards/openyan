﻿using System;
using UnityEngine;

// Token: 0x0200042F RID: 1071
public class AStarHotReloadHelper : MonoBehaviour
{
}
