﻿using System;

// Token: 0x0200033E RID: 830
public enum BodyPartType
{
	// Token: 0x040016EB RID: 5867
	Head,
	// Token: 0x040016EC RID: 5868
	Torso,
	// Token: 0x040016ED RID: 5869
	LeftArm,
	// Token: 0x040016EE RID: 5870
	RightArm,
	// Token: 0x040016EF RID: 5871
	LeftLeg,
	// Token: 0x040016F0 RID: 5872
	RightLeg
}
