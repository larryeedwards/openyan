﻿using System;

// Token: 0x0200057F RID: 1407
[Serializable]
public class ClubTypeHashSet : SerializableHashSet<ClubType>
{
}
