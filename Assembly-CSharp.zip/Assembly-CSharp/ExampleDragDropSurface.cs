﻿using System;
using UnityEngine;

// Token: 0x02000195 RID: 405
[AddComponentMenu("NGUI/Examples/Drag and Drop Surface (Example)")]
public class ExampleDragDropSurface : MonoBehaviour
{
	// Token: 0x04000AFF RID: 2815
	public bool rotatePlacedObject;
}
