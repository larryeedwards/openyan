﻿using System;

// Token: 0x020003B7 RID: 951
public enum GenderType
{
	// Token: 0x04001DD6 RID: 7638
	Male,
	// Token: 0x04001DD7 RID: 7639
	Female
}
