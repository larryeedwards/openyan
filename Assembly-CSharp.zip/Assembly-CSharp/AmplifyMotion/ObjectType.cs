﻿using System;

namespace AmplifyMotion
{
	// Token: 0x0200028E RID: 654
	public enum ObjectType
	{
		// Token: 0x040011CE RID: 4558
		None,
		// Token: 0x040011CF RID: 4559
		Solid,
		// Token: 0x040011D0 RID: 4560
		Skinned,
		// Token: 0x040011D1 RID: 4561
		Cloth,
		// Token: 0x040011D2 RID: 4562
		Particle
	}
}
