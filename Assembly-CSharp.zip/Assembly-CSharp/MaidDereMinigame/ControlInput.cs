﻿using System;

namespace MaidDereMinigame
{
	// Token: 0x02000145 RID: 325
	[Serializable]
	public struct ControlInput
	{
		// Token: 0x04000805 RID: 2053
		public float horizontal;
	}
}
