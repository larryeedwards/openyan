﻿using System;

// Token: 0x02000577 RID: 1399
[Serializable]
public class IntAndStringDictionary : SerializableDictionary<int, string>
{
}
