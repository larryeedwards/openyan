﻿using System;

// Token: 0x02000576 RID: 1398
[Serializable]
public class IntAndIntPairAndBoolDictionary : SerializableDictionary<IntAndIntPair, bool>
{
}
