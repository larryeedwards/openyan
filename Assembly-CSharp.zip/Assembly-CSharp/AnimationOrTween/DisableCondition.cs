﻿using System;

namespace AnimationOrTween
{
	// Token: 0x020001F2 RID: 498
	public enum DisableCondition
	{
		// Token: 0x04000D75 RID: 3445
		DisableAfterReverse = -1,
		// Token: 0x04000D76 RID: 3446
		DoNotDisable,
		// Token: 0x04000D77 RID: 3447
		DisableAfterForward
	}
}
