﻿using System;

// Token: 0x02000598 RID: 1432
public enum MovementType
{
	// Token: 0x04003918 RID: 14616
	Idle,
	// Token: 0x04003919 RID: 14617
	Walking,
	// Token: 0x0400391A RID: 14618
	Running
}
