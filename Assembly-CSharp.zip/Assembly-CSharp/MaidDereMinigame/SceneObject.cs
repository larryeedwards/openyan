﻿using System;
using UnityEngine;

namespace MaidDereMinigame
{
	// Token: 0x02000160 RID: 352
	[CreateAssetMenu(fileName = "New Scene Object", menuName = "Scenes/New Scene Object")]
	[Serializable]
	public class SceneObject : ScriptableObject
	{
		// Token: 0x04000894 RID: 2196
		public int sceneBuildNumber = -1;
	}
}
