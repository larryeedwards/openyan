﻿using System;
using UnityEngine;

// Token: 0x0200028D RID: 653
[AddComponentMenu("Image Effects/Amplify Motion Object")]
public class AmplifyMotionObject : AmplifyMotionObjectBase
{
}
