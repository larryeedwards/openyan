﻿using System;

// Token: 0x020003B6 RID: 950
public enum EntityType
{
	// Token: 0x04001DD2 RID: 7634
	Player,
	// Token: 0x04001DD3 RID: 7635
	Student,
	// Token: 0x04001DD4 RID: 7636
	Teacher
}
