﻿using System;

// Token: 0x02000570 RID: 1392
[Serializable]
public class ClubTypeAndBoolDictionary : SerializableDictionary<ClubType, bool>
{
}
