﻿using System;
using UnityEngine;

// Token: 0x02000471 RID: 1137
public class NodeSetterScript : MonoBehaviour
{
	// Token: 0x06001DE9 RID: 7657 RVA: 0x0011F492 File Offset: 0x0011D892
	private void Start()
	{
	}

	// Token: 0x040025C4 RID: 9668
	public GameObject[] Nodes;

	// Token: 0x040025C5 RID: 9669
	public GameObject Node;

	// Token: 0x040025C6 RID: 9670
	public bool Stairs;

	// Token: 0x040025C7 RID: 9671
	public bool Door;

	// Token: 0x040025C8 RID: 9672
	public float Height;

	// Token: 0x040025C9 RID: 9673
	public int Column;

	// Token: 0x040025CA RID: 9674
	public int Row;
}
