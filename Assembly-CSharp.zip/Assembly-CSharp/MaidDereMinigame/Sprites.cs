﻿using System;
using MaidDereMinigame.Malee;
using UnityEngine;

namespace MaidDereMinigame
{
	// Token: 0x02000152 RID: 338
	[Serializable]
	public class Sprites : ReorderableArray<Sprite>
	{
	}
}
