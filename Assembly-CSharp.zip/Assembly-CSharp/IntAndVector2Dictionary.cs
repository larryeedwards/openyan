﻿using System;
using UnityEngine;

// Token: 0x02000578 RID: 1400
[Serializable]
public class IntAndVector2Dictionary : SerializableDictionary<int, Vector2>
{
}
