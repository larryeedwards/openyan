﻿using System;

// Token: 0x02000572 RID: 1394
[Serializable]
public class IntAndBoolDictionary : SerializableDictionary<int, bool>
{
}
