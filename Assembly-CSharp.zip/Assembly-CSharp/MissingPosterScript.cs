﻿using System;
using UnityEngine;

// Token: 0x02000465 RID: 1125
public class MissingPosterScript : MonoBehaviour
{
	// Token: 0x04002554 RID: 9556
	public Renderer MyRenderer;
}
