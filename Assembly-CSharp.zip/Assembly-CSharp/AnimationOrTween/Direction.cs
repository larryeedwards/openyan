﻿using System;

namespace AnimationOrTween
{
	// Token: 0x020001F0 RID: 496
	public enum Direction
	{
		// Token: 0x04000D6D RID: 3437
		Reverse = -1,
		// Token: 0x04000D6E RID: 3438
		Toggle,
		// Token: 0x04000D6F RID: 3439
		Forward
	}
}
