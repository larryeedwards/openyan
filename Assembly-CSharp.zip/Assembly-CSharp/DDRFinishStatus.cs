﻿using System;

// Token: 0x0200012D RID: 301
public enum DDRFinishStatus
{
	// Token: 0x0400077E RID: 1918
	Complete,
	// Token: 0x0400077F RID: 1919
	Failed
}
