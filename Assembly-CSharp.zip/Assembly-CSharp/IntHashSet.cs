﻿using System;

// Token: 0x02000581 RID: 1409
[Serializable]
public class IntHashSet : SerializableHashSet<int>
{
}
