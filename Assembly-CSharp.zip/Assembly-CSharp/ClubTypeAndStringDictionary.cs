﻿using System;

// Token: 0x02000571 RID: 1393
[Serializable]
public class ClubTypeAndStringDictionary : SerializableDictionary<ClubType, string>
{
}
