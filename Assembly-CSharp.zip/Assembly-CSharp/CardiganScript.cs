﻿using System;
using UnityEngine;

// Token: 0x02000357 RID: 855
public class CardiganScript : MonoBehaviour
{
	// Token: 0x040017B3 RID: 6067
	public SkinnedMeshRenderer MyRenderer;
}
