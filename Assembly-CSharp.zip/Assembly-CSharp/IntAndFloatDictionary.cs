﻿using System;

// Token: 0x02000574 RID: 1396
[Serializable]
public class IntAndFloatDictionary : SerializableDictionary<int, float>
{
}
