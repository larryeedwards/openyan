﻿using System;

// Token: 0x02000579 RID: 1401
[Serializable]
public class NotificationTypeAndStringDictionary : SerializableDictionary<NotificationType, string>
{
}
