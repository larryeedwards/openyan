﻿using System;

// Token: 0x02000434 RID: 1076
public enum InputDeviceType
{
	// Token: 0x040022EF RID: 8943
	Gamepad = 1,
	// Token: 0x040022F0 RID: 8944
	MouseAndKeyboard
}
