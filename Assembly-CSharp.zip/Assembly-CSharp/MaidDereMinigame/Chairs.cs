﻿using System;
using MaidDereMinigame.Malee;

namespace MaidDereMinigame
{
	// Token: 0x02000148 RID: 328
	[Serializable]
	public class Chairs : ReorderableArray<Chair>
	{
	}
}
