﻿using System;

namespace AnimationOrTween
{
	// Token: 0x020001F1 RID: 497
	public enum EnableCondition
	{
		// Token: 0x04000D71 RID: 3441
		DoNothing,
		// Token: 0x04000D72 RID: 3442
		EnableThenPlay,
		// Token: 0x04000D73 RID: 3443
		IgnoreDisabledState
	}
}
