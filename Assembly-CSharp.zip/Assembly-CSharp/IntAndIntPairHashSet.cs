﻿using System;

// Token: 0x02000580 RID: 1408
[Serializable]
public class IntAndIntPairHashSet : SerializableHashSet<IntAndIntPair>
{
}
