﻿using System;
using MaidDereMinigame.Malee;
using UnityEngine;

namespace MaidDereMinigame
{
	// Token: 0x0200016B RID: 363
	[Serializable]
	public class SpriteRenderers : ReorderableArray<SpriteRenderer>
	{
	}
}
