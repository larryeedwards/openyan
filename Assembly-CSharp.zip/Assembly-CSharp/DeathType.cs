﻿using System;

// Token: 0x020003B8 RID: 952
public enum DeathType
{
	// Token: 0x04001DD9 RID: 7641
	None,
	// Token: 0x04001DDA RID: 7642
	Burning,
	// Token: 0x04001DDB RID: 7643
	Disposed,
	// Token: 0x04001DDC RID: 7644
	Drowning,
	// Token: 0x04001DDD RID: 7645
	EasterEgg,
	// Token: 0x04001DDE RID: 7646
	Electrocution,
	// Token: 0x04001DDF RID: 7647
	Falling,
	// Token: 0x04001DE0 RID: 7648
	Poison,
	// Token: 0x04001DE1 RID: 7649
	Weapon,
	// Token: 0x04001DE2 RID: 7650
	Mystery,
	// Token: 0x04001DE3 RID: 7651
	Weight
}
