﻿using System;

// Token: 0x02000568 RID: 1384
public enum Direction
{
	// Token: 0x04003756 RID: 14166
	North,
	// Token: 0x04003757 RID: 14167
	East,
	// Token: 0x04003758 RID: 14168
	South,
	// Token: 0x04003759 RID: 14169
	West
}
