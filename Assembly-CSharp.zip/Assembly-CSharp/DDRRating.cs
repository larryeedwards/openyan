﻿using System;

// Token: 0x0200012C RID: 300
public enum DDRRating
{
	// Token: 0x04000777 RID: 1911
	Perfect,
	// Token: 0x04000778 RID: 1912
	Great,
	// Token: 0x04000779 RID: 1913
	Good,
	// Token: 0x0400077A RID: 1914
	Ok,
	// Token: 0x0400077B RID: 1915
	Miss,
	// Token: 0x0400077C RID: 1916
	Early
}
