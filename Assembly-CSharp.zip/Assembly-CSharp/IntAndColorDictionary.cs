﻿using System;
using UnityEngine;

// Token: 0x02000573 RID: 1395
[Serializable]
public class IntAndColorDictionary : SerializableDictionary<int, Color>
{
}
