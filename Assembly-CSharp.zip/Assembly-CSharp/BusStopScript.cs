﻿using System;
using UnityEngine;

// Token: 0x0200034E RID: 846
public class BusStopScript : MonoBehaviour
{
}
