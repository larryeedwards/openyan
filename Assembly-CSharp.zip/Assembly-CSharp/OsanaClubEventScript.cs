﻿using System;
using UnityEngine;

// Token: 0x020004C5 RID: 1221
public class OsanaClubEventScript : MonoBehaviour
{
	// Token: 0x06001F34 RID: 7988 RVA: 0x0013F5D4 File Offset: 0x0013D9D4
	public void EndEvent()
	{
	}
}
