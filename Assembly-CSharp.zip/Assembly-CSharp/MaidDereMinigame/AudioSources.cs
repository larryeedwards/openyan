﻿using System;
using MaidDereMinigame.Malee;
using UnityEngine;

namespace MaidDereMinigame
{
	// Token: 0x0200015A RID: 346
	[Serializable]
	public class AudioSources : ReorderableArray<AudioSource>
	{
	}
}
