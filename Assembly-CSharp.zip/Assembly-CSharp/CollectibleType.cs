﻿using System;

// Token: 0x0200036E RID: 878
public enum CollectibleType
{
	// Token: 0x040018C3 RID: 6339
	HeadmasterTape,
	// Token: 0x040018C4 RID: 6340
	BasementTape,
	// Token: 0x040018C5 RID: 6341
	Manga,
	// Token: 0x040018C6 RID: 6342
	Tape,
	// Token: 0x040018C7 RID: 6343
	Key
}
