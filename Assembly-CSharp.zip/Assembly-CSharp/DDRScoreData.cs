﻿using System;

// Token: 0x02000130 RID: 304
[Serializable]
public struct DDRScoreData
{
	// Token: 0x04000787 RID: 1927
	public DDRRating Rating;

	// Token: 0x04000788 RID: 1928
	public float Points;
}
