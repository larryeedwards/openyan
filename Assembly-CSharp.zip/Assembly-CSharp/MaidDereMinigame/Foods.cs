﻿using System;
using MaidDereMinigame.Malee;

namespace MaidDereMinigame
{
	// Token: 0x0200014D RID: 333
	[Serializable]
	public class Foods : ReorderableArray<Food>
	{
	}
}
