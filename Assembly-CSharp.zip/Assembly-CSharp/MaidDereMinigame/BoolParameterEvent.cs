﻿using System;

namespace MaidDereMinigame
{
	// Token: 0x02000150 RID: 336
	// (Invoke) Token: 0x06000B53 RID: 2899
	public delegate void BoolParameterEvent(bool b);
}
