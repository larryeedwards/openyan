﻿using System;

// Token: 0x02000474 RID: 1140
public enum NotificationType
{
	// Token: 0x04002607 RID: 9735
	Bloody,
	// Token: 0x04002608 RID: 9736
	Body,
	// Token: 0x04002609 RID: 9737
	Insane,
	// Token: 0x0400260A RID: 9738
	Armed,
	// Token: 0x0400260B RID: 9739
	Lewd,
	// Token: 0x0400260C RID: 9740
	Intrude,
	// Token: 0x0400260D RID: 9741
	Late,
	// Token: 0x0400260E RID: 9742
	Info,
	// Token: 0x0400260F RID: 9743
	Topic,
	// Token: 0x04002610 RID: 9744
	Opinion,
	// Token: 0x04002611 RID: 9745
	Complete,
	// Token: 0x04002612 RID: 9746
	Exfiltrate,
	// Token: 0x04002613 RID: 9747
	Evidence,
	// Token: 0x04002614 RID: 9748
	ClassSoon,
	// Token: 0x04002615 RID: 9749
	ClassNow,
	// Token: 0x04002616 RID: 9750
	Eavesdropping,
	// Token: 0x04002617 RID: 9751
	Persona,
	// Token: 0x04002618 RID: 9752
	Clothing,
	// Token: 0x04002619 RID: 9753
	Custom
}
