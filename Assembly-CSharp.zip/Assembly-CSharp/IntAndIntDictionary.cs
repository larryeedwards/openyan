﻿using System;

// Token: 0x02000575 RID: 1397
[Serializable]
public class IntAndIntDictionary : SerializableDictionary<int, int>
{
}
