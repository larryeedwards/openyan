﻿using System;
using MaidDereMinigame.Malee;
using UnityEngine;

namespace MaidDereMinigame
{
	// Token: 0x02000159 RID: 345
	[Serializable]
	public class AudioClips : ReorderableArray<AudioClip>
	{
	}
}
